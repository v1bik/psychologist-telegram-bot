// Настройка EmailJS для получения заявок
export const sendBookingEmail = async (bookingData: any) => {
  // Отправка заявки на вашу почту
  const response = await fetch("/api/send-booking", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(bookingData),
  })
  return response.json()
}
