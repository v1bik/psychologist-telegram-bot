// Интеграция с ЮKassa
export const createPayment = async (amount: number, description: string) => {
  const response = await fetch("/api/create-payment", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ amount, description }),
  })
  return response.json()
}
