"use client"

import { useState } from "react"
import { Edit, Save, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import PhotoUpload from "./photo-upload"
import { usePhotoStorage } from "@/hooks/use-photo-storage"

interface EditableContent {
  name: string
  title: string
  description: string
  heroTitle: string
  heroDescription: string
  aboutTitle: string
  aboutDescription: string
  approachTitle: string
  approachDescription: string
  servicesTitle: string
  servicesDescription: string
  individualServiceTitle: string
  individualServiceDescription: string
  familyServiceTitle: string
  familyServiceDescription: string
  onlineServiceTitle: string
  onlineServiceDescription: string
  pricesTitle: string
  pricesDescription: string
  contactTitle: string
  contactDescription: string
  experience: string
  education: string
  individualPrice: string
  familyPrice: string
  phone: string
  email: string
  address: string
  workingHours: string
  footerDescription: string
}

export default function AdminPanel() {
  const [isEditing, setIsEditing] = useState(false)
  const [content, setContent] = useState<EditableContent>({
    name: "Вадим Чумаев",
    title: "Психолог-консультант",
    description: "Помогаю людям найти внутреннюю гармонию, преодолеть трудности и построить здоровые отношения.",
    heroTitle: "Вадим Чумаев",
    heroDescription:
      "Помогаю людям найти внутреннюю гармонию, преодолеть трудности и построить здоровые отношения. Индивидуальная и семейная психотерапия с профессиональным подходом.",
    aboutTitle: "О себе",
    aboutDescription: "Профессиональный психолог с современным подходом к решению личных и семейных проблем",
    approachTitle: "Мой подход к работе",
    approachDescription:
      "Я верю, что каждый человек обладает внутренними ресурсами для преодоления трудностей. Моя задача — помочь вам их обнаружить и эффективно использовать.",
    servicesTitle: "Услуги",
    servicesDescription: "Профессиональная психологическая помощь для решения различных жизненных ситуаций",
    individualServiceTitle: "Индивидуальная терапия",
    individualServiceDescription: "Работа с личными проблемами, тревожностью, депрессией, самооценкой",
    familyServiceTitle: "Семейная терапия",
    familyServiceDescription: "Восстановление отношений, решение семейных конфликтов",
    onlineServiceTitle: "Онлайн консультации",
    onlineServiceDescription: "Удобный формат работы из любой точки мира",
    pricesTitle: "Стоимость услуг",
    pricesDescription: "Прозрачные цены без скрытых платежей",
    contactTitle: "Связаться со мной",
    contactDescription: "Готов ответить на ваши вопросы и записать на консультацию",
    experience: "2 года практической деятельности",
    education: "Московская международная аккадемия",
    individualPrice: "1500",
    familyPrice: "2500",
    phone: "+7 916-705-9110",
    email: "vadimchumaev@mail.ru",
    address: "Москва, ул. Прим��рная, д. 123",
    workingHours: "Пн-Пт: 10:00-20:00",
    footerDescription:
      "Профессиональная психологическая помощь для обретения внутренней гармонии и решения жизненных трудностей.",
  })

  const { photo, updatePhoto } = usePhotoStorage()

  const handleSave = () => {
    // Здесь будет логика сохранения данных включая фото
    console.log("Saving content:", { ...content, photo })
    setIsEditing(false)
    alert("Изменения сохранены!")
  }

  const handleCancel = () => {
    setIsEditing(false)
    // Здесь можно восстановить предыдущие значения
  }

  const handleInputChange = (field: keyof EditableContent, value: string) => {
    setContent((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Панель редактирования</h1>
          <div className="flex gap-2">
            {!isEditing ? (
              <Button onClick={() => setIsEditing(true)} className="bg-blue-600 hover:bg-blue-700">
                <Edit className="h-4 w-4 mr-2" />
                Редактировать
              </Button>
            ) : (
              <>
                <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">
                  <Save className="h-4 w-4 mr-2" />
                  Сохранить
                </Button>
                <Button onClick={handleCancel} variant="outline">
                  <X className="h-4 w-4 mr-2" />
                  Отмена
                </Button>
              </>
            )}
          </div>
        </div>

        <div className="grid gap-6">
          {/* Основная информация */}
          <Card>
            <CardHeader>
              <CardTitle>Основная информация</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Имя</Label>
                {isEditing ? (
                  <Input
                    id="name"
                    value={content.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.name}</p>
                )}
              </div>

              <div>
                <Label htmlFor="title">Должность</Label>
                {isEditing ? (
                  <Input
                    id="title"
                    value={content.title}
                    onChange={(e) => handleInputChange("title", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.title}</p>
                )}
              </div>

              <div>
                <Label htmlFor="description">Описание</Label>
                {isEditing ? (
                  <Textarea
                    id="description"
                    value={content.description}
                    onChange={(e) => handleInputChange("description", e.target.value)}
                    className="mt-1 min-h-[100px]"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.description}</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Фотография */}
          <PhotoUpload currentPhoto={photo} onPhotoChange={updatePhoto} isEditing={isEditing} />

          {/* Образование и опыт */}
          <Card>
            <CardHeader>
              <CardTitle>Образование и опыт</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="education">Образование</Label>
                {isEditing ? (
                  <Input
                    id="education"
                    value={content.education}
                    onChange={(e) => handleInputChange("education", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.education}</p>
                )}
              </div>

              <div>
                <Label htmlFor="experience">Опыт работы</Label>
                {isEditing ? (
                  <Input
                    id="experience"
                    value={content.experience}
                    onChange={(e) => handleInputChange("experience", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.experience}</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Цены */}
          <Card>
            <CardHeader>
              <CardTitle>Стоимость услуг</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="individualPrice">Индивидуальная консультация (₽)</Label>
                {isEditing ? (
                  <Input
                    id="individualPrice"
                    type="number"
                    value={content.individualPrice}
                    onChange={(e) => handleInputChange("individualPrice", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.individualPrice} ₽</p>
                )}
              </div>

              <div>
                <Label htmlFor="familyPrice">Семейная терапия (₽)</Label>
                {isEditing ? (
                  <Input
                    id="familyPrice"
                    type="number"
                    value={content.familyPrice}
                    onChange={(e) => handleInputChange("familyPrice", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.familyPrice} ₽</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Контактная информация */}
          <Card>
            <CardHeader>
              <CardTitle>Контактная информация</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="phone">Телефон</Label>
                {isEditing ? (
                  <Input
                    id="phone"
                    value={content.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.phone}</p>
                )}
              </div>

              <div>
                <Label htmlFor="email">Email</Label>
                {isEditing ? (
                  <Input
                    id="email"
                    type="email"
                    value={content.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.email}</p>
                )}
              </div>

              <div>
                <Label htmlFor="address">Адрес</Label>
                {isEditing ? (
                  <Input
                    id="address"
                    value={content.address}
                    onChange={(e) => handleInputChange("address", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.address}</p>
                )}
              </div>

              <div>
                <Label htmlFor="workingHours">Часы работы</Label>
                {isEditing ? (
                  <Input
                    id="workingHours"
                    value={content.workingHours}
                    onChange={(e) => handleInputChange("workingHours", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.workingHours}</p>
                )}
              </div>
            </CardContent>
          </Card>
          {/* Тексты главной страницы */}
          <Card>
            <CardHeader>
              <CardTitle>Главная страница</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="heroTitle">Заголовок героя</Label>
                {isEditing ? (
                  <Input
                    id="heroTitle"
                    value={content.heroTitle}
                    onChange={(e) => handleInputChange("heroTitle", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.heroTitle}</p>
                )}
              </div>

              <div>
                <Label htmlFor="heroDescription">Описание героя</Label>
                {isEditing ? (
                  <Textarea
                    id="heroDescription"
                    value={content.heroDescription}
                    onChange={(e) => handleInputChange("heroDescription", e.target.value)}
                    className="mt-1 min-h-[100px]"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.heroDescription}</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Тексты разделов */}
          <Card>
            <CardHeader>
              <CardTitle>Заголовки разделов</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="aboutTitle">Заголовок "О себе"</Label>
                {isEditing ? (
                  <Input
                    id="aboutTitle"
                    value={content.aboutTitle}
                    onChange={(e) => handleInputChange("aboutTitle", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.aboutTitle}</p>
                )}
              </div>

              <div>
                <Label htmlFor="servicesTitle">Заголовок "Услуги"</Label>
                {isEditing ? (
                  <Input
                    id="servicesTitle"
                    value={content.servicesTitle}
                    onChange={(e) => handleInputChange("servicesTitle", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.servicesTitle}</p>
                )}
              </div>

              <div>
                <Label htmlFor="pricesTitle">Заголовок "Цены"</Label>
                {isEditing ? (
                  <Input
                    id="pricesTitle"
                    value={content.pricesTitle}
                    onChange={(e) => handleInputChange("pricesTitle", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.pricesTitle}</p>
                )}
              </div>

              <div>
                <Label htmlFor="contactTitle">Заголовок "Контакты"</Label>
                {isEditing ? (
                  <Input
                    id="contactTitle"
                    value={content.contactTitle}
                    onChange={(e) => handleInputChange("contactTitle", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.contactTitle}</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Описания услуг */}
          <Card>
            <CardHeader>
              <CardTitle>Описания услуг</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="individualServiceTitle">Индивидуальная терапия - заголовок</Label>
                {isEditing ? (
                  <Input
                    id="individualServiceTitle"
                    value={content.individualServiceTitle}
                    onChange={(e) => handleInputChange("individualServiceTitle", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.individualServiceTitle}</p>
                )}
              </div>

              <div>
                <Label htmlFor="individualServiceDescription">Индивидуальная терапия - описание</Label>
                {isEditing ? (
                  <Textarea
                    id="individualServiceDescription"
                    value={content.individualServiceDescription}
                    onChange={(e) => handleInputChange("individualServiceDescription", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.individualServiceDescription}</p>
                )}
              </div>

              <div>
                <Label htmlFor="familyServiceTitle">Семейная терапия - заголовок</Label>
                {isEditing ? (
                  <Input
                    id="familyServiceTitle"
                    value={content.familyServiceTitle}
                    onChange={(e) => handleInputChange("familyServiceTitle", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.familyServiceTitle}</p>
                )}
              </div>

              <div>
                <Label htmlFor="familyServiceDescription">Семейная терапия - описание</Label>
                {isEditing ? (
                  <Textarea
                    id="familyServiceDescription"
                    value={content.familyServiceDescription}
                    onChange={(e) => handleInputChange("familyServiceDescription", e.target.value)}
                    className="mt-1"
                  />
                ) : (
                  <p className="mt-1 p-2 bg-gray-50 rounded">{content.familyServiceDescription}</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
