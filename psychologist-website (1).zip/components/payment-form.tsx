"use client"

import type React from "react"

import { useState } from "react"
import { Lock, Check } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"

interface PaymentFormProps {
  service: string
  price: number
  onPayment: (paymentData: any) => void
  onCancel: () => void
}

export default function PaymentForm({ service, price, onPayment, onCancel }: PaymentFormProps) {
  const [paymentData, setPaymentData] = useState({
    cardNumber: "",
    expiryDate: "",
    cvv: "",
    cardHolder: "",
    email: "",
    phone: "",
    paymentMethod: "card",
  })

  const [isProcessing, setIsProcessing] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    // Имитация обработки платежа
    await new Promise((resolve) => setTimeout(resolve, 2000))

    onPayment(paymentData)
    setIsProcessing(false)
  }

  const handleInputChange = (field: string, value: string) => {
    setPaymentData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  return (
    <Card className="w-full">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2">
          <Lock className="h-5 w-5 text-green-600" />
          Безопасная оплата
        </CardTitle>
        <CardDescription>Все данные защищены SSL-шифрованием</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Информация о заказе */}
          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-900">{service}</h3>
            <div className="flex justify-between items-center mt-2">
              <span className="text-gray-600">Стоимость:</span>
              <span className="text-2xl font-bold text-blue-600">{price} ₽</span>
            </div>
          </div>

          <Separator />

          {/* Способ оплаты */}
          <div>
            <Label>Способ оплаты</Label>
            <Select
              value={paymentData.paymentMethod}
              onValueChange={(value) => handleInputChange("paymentMethod", value)}
            >
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="card">💳 Банковская карта</SelectItem>
                <SelectItem value="sbp">📱 СБП (Система быстрых платежей)</SelectItem>
                <SelectItem value="yandex">🟡 Яндекс.Деньги</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {paymentData.paymentMethod === "card" && (
            <>
              {/* Данные карты */}
              <div>
                <Label htmlFor="cardNumber">Номер карты *</Label>
                <Input
                  id="cardNumber"
                  value={paymentData.cardNumber}
                  onChange={(e) => handleInputChange("cardNumber", e.target.value)}
                  placeholder="1234 5678 9012 3456"
                  required
                  className="mt-1"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="expiryDate">Срок действия *</Label>
                  <Input
                    id="expiryDate"
                    value={paymentData.expiryDate}
                    onChange={(e) => handleInputChange("expiryDate", e.target.value)}
                    placeholder="MM/YY"
                    required
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="cvv">CVV *</Label>
                  <Input
                    id="cvv"
                    value={paymentData.cvv}
                    onChange={(e) => handleInputChange("cvv", e.target.value)}
                    placeholder="123"
                    required
                    className="mt-1"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="cardHolder">Имя держателя карты *</Label>
                <Input
                  id="cardHolder"
                  value={paymentData.cardHolder}
                  onChange={(e) => handleInputChange("cardHolder", e.target.value)}
                  placeholder="IVAN PETROV"
                  required
                  className="mt-1"
                />
              </div>
            </>
          )}

          {/* Контактные данные */}
          <Separator />

          <div>
            <Label htmlFor="email">Email для чека *</Label>
            <Input
              id="email"
              type="email"
              value={paymentData.email}
              onChange={(e) => handleInputChange("email", e.target.value)}
              placeholder="your@email.com"
              required
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="phone">Телефон *</Label>
            <Input
              id="phone"
              value={paymentData.phone}
              onChange={(e) => handleInputChange("phone", e.target.value)}
              placeholder="+7 (999) 123-45-67"
              required
              className="mt-1"
            />
          </div>

          {/* Кнопки */}
          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1" disabled={isProcessing}>
              Отмена
            </Button>
            <Button type="submit" className="flex-1 bg-green-600 hover:bg-green-700" disabled={isProcessing}>
              {isProcessing ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Обработка...
                </>
              ) : (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Оплатить {price} ₽
                </>
              )}
            </Button>
          </div>
        </form>

        {/* Информация о безопасности */}
        <div className="mt-6 p-3 bg-gray-50 rounded-lg text-sm text-gray-600 text-center">
          <Lock className="h-4 w-4 inline mr-1" />
          Ваши данные защищены 256-битным SSL-шифрованием
        </div>
      </CardContent>
    </Card>
  )
}
