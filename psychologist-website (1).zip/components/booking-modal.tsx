"use client"

import type React from "react"

import { useState } from "react"
import { Calendar } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface BookingModalProps {
  isOpen: boolean
  onClose: () => void
  serviceType?: string
}

export default function BookingModal({ isOpen, onClose, serviceType = "" }: BookingModalProps) {
  const [bookingData, setBookingData] = useState({
    name: "",
    email: "",
    phone: "",
    service: serviceType,
    date: "",
    time: "",
    message: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Имитация отправки данных
    await new Promise((resolve) => setTimeout(resolve, 1500))

    console.log("Booking submitted:", bookingData)
    alert(
      `Спасибо, ${bookingData.name}! Ваша заявка на ${bookingData.service} принята. Я свяжусь с вами в ближайшее время для подтверждения записи.`,
    )

    // Сброс формы
    setBookingData({
      name: "",
      email: "",
      phone: "",
      service: "",
      date: "",
      time: "",
      message: "",
    })

    setIsSubmitting(false)
    onClose()
  }

  const handleInputChange = (field: string, value: string) => {
    setBookingData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  // Генерация доступных дат (следующие 14 дней, исключая выходные)
  const getAvailableDates = () => {
    const dates = []
    const today = new Date()

    for (let i = 1; i <= 14; i++) {
      const date = new Date(today)
      date.setDate(today.getDate() + i)

      // Исключаем выходные (суббота = 6, воскресенье = 0)
      if (date.getDay() !== 0 && date.getDay() !== 6) {
        dates.push({
          value: date.toISOString().split("T")[0],
          label: date.toLocaleDateString("ru-RU", {
            weekday: "long",
            day: "numeric",
            month: "long",
          }),
        })
      }
    }
    return dates
  }

  const availableTimes = ["10:00", "11:00", "12:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00"]

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-blue-600" />
            Записаться на консультацию
          </DialogTitle>
          <DialogDescription>Заполните форму, и я свяжусь с вами для подтверждения записи</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Личные данные */}
          <div className="grid grid-cols-1 gap-4">
            <div>
              <Label htmlFor="name">Имя *</Label>
              <Input
                id="name"
                value={bookingData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                placeholder="Ваше имя"
                required
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="phone">Телефон *</Label>
              <Input
                id="phone"
                type="tel"
                value={bookingData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                placeholder="+7 (999) 123-45-67"
                required
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={bookingData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                placeholder="your@email.com"
                className="mt-1"
              />
            </div>
          </div>

          {/* Выбор услуги */}
          <div>
            <Label>Тип консультации *</Label>
            <Select value={bookingData.service} onValueChange={(value) => handleInputChange("service", value)}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Выберите тип консультации" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="individual">Индивидуальная консультация (1500₽)</SelectItem>
                <SelectItem value="family">Семейная терапия (2500₽)</SelectItem>
                <SelectItem value="online">Онлайн консультация (1500₽)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Выбор даты и времени */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Предпочитаемая дата</Label>
              <Select value={bookingData.date} onValueChange={(value) => handleInputChange("date", value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Выберите дату" />
                </SelectTrigger>
                <SelectContent>
                  {getAvailableDates().map((date) => (
                    <SelectItem key={date.value} value={date.value}>
                      {date.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Предпочитаемое время</Label>
              <Select value={bookingData.time} onValueChange={(value) => handleInputChange("time", value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Выберите время" />
                </SelectTrigger>
                <SelectContent>
                  {availableTimes.map((time) => (
                    <SelectItem key={time} value={time}>
                      {time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Дополнительная информация */}
          <div>
            <Label htmlFor="message">Дополнительная информация</Label>
            <Textarea
              id="message"
              value={bookingData.message}
              onChange={(e) => handleInputChange("message", e.target.value)}
              placeholder="Расскажите кратко о вашей ситуации или вопросах..."
              className="mt-1 min-h-[80px]"
            />
          </div>

          {/* Информационное сообщение */}
          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm text-blue-700">
              <strong>Обратите внимание:</strong> После отправки заявки я свяжусь с вами в течение 2-3 часов для
              подтверждения записи и уточнения деталей.
            </p>
          </div>

          {/* Кнопки */}
          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1" disabled={isSubmitting}>
              Отмена
            </Button>
            <Button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Отправка...
                </>
              ) : (
                <>
                  <Calendar className="h-4 w-4 mr-2" />
                  Записаться
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
