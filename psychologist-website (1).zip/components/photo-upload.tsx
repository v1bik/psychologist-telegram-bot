"use client"

import type React from "react"

import { useState } from "react"
import { Upload, X, Camera } from "lucide-react"
import Image from "next/image"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface PhotoUploadProps {
  currentPhoto: string
  onPhotoChange: (photo: string) => void
  isEditing: boolean
}

export default function PhotoUpload({ currentPhoto, onPhotoChange, isEditing }: PhotoUploadProps) {
  const [dragOver, setDragOver] = useState(false)

  const handleFileUpload = (file: File) => {
    if (file && file.type.startsWith("image/")) {
      const reader = new FileReader()
      reader.onload = (event) => {
        const result = event.target?.result as string
        onPhotoChange(result)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      handleFileUpload(file)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files[0]
    if (file) {
      handleFileUpload(file)
    }
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
  }

  const handleRemovePhoto = () => {
    onPhotoChange("/images/vadim-photo.jpg")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Camera className="h-5 w-5" />
          Фотография
        </CardTitle>
        <CardDescription>Загрузите профессиональное фото для сайта</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Предварительный просмотр */}
        <div className="flex justify-center">
          <div className="relative">
            <Image
              src={currentPhoto || "/images/vadim-photo.jpg"}
              alt="Фото психолога"
              width={250}
              height={300}
              className="rounded-xl shadow-lg object-cover border-4 border-gray-100"
            />
            {isEditing && currentPhoto !== "/images/vadim-photo.jpg" && (
              <Button
                onClick={handleRemovePhoto}
                size="sm"
                variant="destructive"
                className="absolute -top-2 -right-2 rounded-full h-8 w-8 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>

        {isEditing && (
          <div className="space-y-4">
            {/* Drag & Drop зона */}
            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                dragOver ? "border-blue-500 bg-blue-50" : "border-gray-300 hover:border-gray-400 hover:bg-gray-50"
              }`}
            >
              <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-lg font-medium text-gray-700 mb-2">Перетащите фото сюда</p>
              <p className="text-sm text-gray-500 mb-4">или нажмите кнопку ниже</p>

              <Label htmlFor="photo-upload" className="cursor-pointer">
                <div className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                  <Upload className="h-4 w-4 mr-2" />
                  Выбрать файл
                </div>
              </Label>
              <Input id="photo-upload" type="file" accept="image/*" onChange={handleInputChange} className="hidden" />
            </div>

            {/* Рекомендации */}
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Рекомендации для фото:</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li>• Используйте профессиональное фото в деловом стиле</li>
                <li>• Рекомендуемый размер: минимум 500x600 пикселей</li>
                <li>• Форматы: JPG, PNG, WebP</li>
                <li>• Хорошее освещение и четкость изображения</li>
                <li>• Нейтральный или офисный фон</li>
              </ul>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
