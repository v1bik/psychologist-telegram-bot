const TelegramBot = require("node-telegram-bot-api")

// Замените на ваш токен от @BotFather
const token = "YOUR_BOT_TOKEN_HERE"
const bot = new TelegramBot(token, { polling: true })

// База данных пользователей (в реальном проекте используйте настоящую БД)
const users = new Map()
const appointments = new Map()

// Главное меню
const mainMenu = {
  reply_markup: {
    keyboard: [
      ["📅 Записаться на прием", "👨‍⚕️ О психологе"],
      ["💰 Цены и услуги", "📞 Контакты"],
      ["🆘 Экстренная помощь", "❓ Частые вопросы"],
      ["📝 Оставить отзыв", "🔒 Конфиденциальность"],
    ],
    resize_keyboard: true,
    one_time_keyboard: false,
  },
}

// Меню услуг
const servicesMenu = {
  reply_markup: {
    inline_keyboard: [
      [{ text: "👤 Индивидуальная терапия (1500₽)", callback_data: "service_individual" }],
      [{ text: "👨‍👩‍👧‍👦 Семейная терапия (2500₽)", callback_data: "service_family" }],
      [{ text: "💻 Онлайн консультация (1500₽)", callback_data: "service_online" }],
      [{ text: "🧠 Диагностика расстройств (2000₽)", callback_data: "service_diagnosis" }],
      [{ text: "🔙 Назад в главное меню", callback_data: "main_menu" }],
    ],
  },
}

// Меню времени записи
const timeMenu = {
  reply_markup: {
    inline_keyboard: [
      [
        { text: "🌅 10:00", callback_data: "time_10" },
        { text: "🌅 11:00", callback_data: "time_11" },
      ],
      [
        { text: "🌞 12:00", callback_data: "time_12" },
        { text: "🌞 14:00", callback_data: "time_14" },
      ],
      [
        { text: "🌆 15:00", callback_data: "time_15" },
        { text: "🌆 16:00", callback_data: "time_16" },
      ],
      [
        { text: "🌃 17:00", callback_data: "time_17" },
        { text: "🌃 18:00", callback_data: "time_18" },
      ],
      [{ text: "🔙 Назад", callback_data: "back_to_booking" }],
    ],
  },
}

// Стартовое сообщение
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id
  const firstName = msg.from.first_name || "Друг"

  // Сохраняем пользователя
  users.set(chatId, {
    firstName: firstName,
    username: msg.from.username,
    joinDate: new Date(),
  })

  const welcomeMessage = `
🌟 *Добро пожаловать, ${firstName}!*

Я бот психолога *Чумаева Вадима Дмитриевича*

👨‍⚕️ *Обо мне:*
• Психолог-консультант
• 2 года практической деятельности  
• Московская международная академия
• Специализация: индивидуальная и семейная терапия

🎯 *Мои услуги:*
• Индивидуальная терапия
• Семейная терапия  
• Онлайн консультации
• Диагностика психических расстройств

💡 *Что я могу помочь решить:*
• Тревожность и страхи
• Депрессивные состояния
• Семейные конфликты
• Проблемы самооценки
• Диагностика расстройств личности

📱 *Через этого бота вы можете:*
✅ Записаться на прием
✅ Узнать цены
✅ Задать вопрос анонимно
✅ Получить экстренную поддержку

🔒 *Полная конфиденциальность гарантирована*

Выберите нужный пункт в меню ⬇️
  `

  bot.sendMessage(chatId, welcomeMessage, {
    parse_mode: "Markdown",
    ...mainMenu,
  })
})

// Обработка текстовых сообщений
bot.on("message", (msg) => {
  const chatId = msg.chat.id
  const text = msg.text

  if (text === "/start") return // Уже обработано выше

  switch (text) {
    case "📅 Записаться на прием":
      handleBooking(chatId)
      break

    case "👨‍⚕️ О психологе":
      handleAbout(chatId)
      break

    case "💰 Цены и услуги":
      handleServices(chatId)
      break

    case "📞 Контакты":
      handleContacts(chatId)
      break

    case "🆘 Экстренная помощь":
      handleEmergency(chatId)
      break

    case "❓ Частые вопросы":
      handleFAQ(chatId)
      break

    case "📝 Оставить отзыв":
      handleReview(chatId)
      break

    case "🔒 Конфиденциальность":
      handlePrivacy(chatId)
      break

    default:
      // Если сообщение не распознано, показываем главное меню
      bot.sendMessage(chatId, "🤔 Не понял вас. Выберите пункт из меню:", mainMenu)
  }
})

// Функция записи на прием
function handleBooking(chatId) {
  const message = `
📅 *ЗАПИСЬ НА ПРИЕМ*

Выберите тип консультации:

👤 *Индивидуальная терапия* - 1500₽
• Работа с личными проблемами
• Тревожность, депрессия
• Повышение самооценки
• Длительность: 50 минут

👨‍👩‍👧‍👦 *Семейная терапия* - 2500₽  
• Семейные конфликты
• Детско-родительские отношения
• Кризис в отношениях
• Длительность: 60 минут

💻 *Онлайн консультация* - 1500₽
• Zoom/Telegram видеосвязь
• Удобно из дома
• Гибкое расписание
• Длительность: 50 минут

🧠 *Диагностика расстройств* - 2000₽
• Психологическое тестирование
• Выявление расстройств личности
• Подробное заключение
• Длительность: 90 минут

⬇️ *Нажмите на нужную услугу:*
  `

  bot.sendMessage(chatId, message, {
    parse_mode: "Markdown",
    ...servicesMenu,
  })
}

// О психологе
function handleAbout(chatId) {
  const message = `
👨‍⚕️ *ЧУМАЕВ ВАДИМ ДМИТРИЕВИЧ*

🎓 *Образование:*
Московская международная академия

⏰ *Опыт работы:*
2 года практической деятельности

🎯 *Специализация:*
• Индивидуальная психотерапия
• Семейная терапия
• Диагностика психических расстройств
• Когнитивно-поведенческая терапия

💡 *Мой подход:*
Я верю, что каждый человек обладает внутренними ресурсами для преодоления трудностей. Моя задача — помочь вам их обнаружить и эффективно использовать.

🏆 *Результаты:*
• 50+ довольных клиентов
• 200+ проведенных сессий
• Индивидуальный подход к каждому

🔒 *Принципы работы:*
• Полная конфиденциальность
• Безоценочное принятие
• Профессиональная этика
• Современные методы терапии

📍 *Прием:* Москва + онлайн по всему миру
  `

  bot.sendMessage(chatId, message, {
    parse_mode: "Markdown",
    ...mainMenu,
  })
}

// Услуги и цены
function handleServices(chatId) {
  const message = `
💰 *ЦЕНЫ И УСЛУГИ*

👤 *Индивидуальная терапия* - *1500₽*
• Тревожность и панические атаки
• Депрессивные состояния  
• Проблемы самооценки
• Эмоциональное выгорание
• Кризисы и потери

👨‍👩‍👧‍👦 *Семейная терапия* - *2500₽*
• Конфликты в паре
• Детско-родительские отношения
• Кризис в браке
• Подготовка к разводу
• Воспитание детей

💻 *Онлайн консультации* - *1500₽*
• Видеосвязь Zoom/Telegram
• Из любой точки мира
• Удобное время
• Та же эффективность

🧠 *Диагностика расстройств* - *2000₽*
• Психологическое тестирование
• MMPI, 16PF, другие методики
• Расстройства личности
• Подробное заключение
• Рекомендации по лечению

🎁 *АКЦИЯ для новых клиентов:*
Первая консультация со скидкой 20%
*Индивидуальная: 1200₽ вместо 1500₽*

💳 *Способы оплаты:*
• Наличные
• Банковская карта
• СБП (Система быстрых платежей)
• Яндекс.Деньги
  `

  bot.sendMessage(chatId, message, {
    parse_mode: "Markdown",
    ...servicesMenu,
  })
}

// Контакты
function handleContacts(chatId) {
  const message = `
📞 *КОНТАКТЫ*

👨‍⚕️ *Психолог:* Чумаев Вадим Дмитриевич

📱 *Телефон:* +7 (916) 705-91-10
📧 *Email:* vadimchumaev@mail.ru
🌐 *Сайт:* vadim-psiholog.ru

📍 *Адрес приема:*
Москва (точный адрес сообщу при записи)

⏰ *Часы работы:*
Понедельник - Пятница: 10:00 - 20:00
Суббота - Воскресенье: Выходной

💬 *Связь со мной:*
• Telegram: @vadim_psychologist
• WhatsApp: +7 (916) 705-91-10
• Звонок: +7 (916) 705-91-10

🚗 *Как добраться:*
Подробную схему проезда пришлю после записи

⚡ *Быстрая связь:*
Отвечаю в течение 2-3 часов
В экстренных случаях - сразу

🔒 *Конфиденциальность:*
Все обращения строго конфиденциальны
  `

  bot.sendMessage(chatId, message, {
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "📱 Позвонить", url: "tel:+79167059110" }],
        [{ text: "💬 WhatsApp", url: "https://wa.me/79167059110" }],
        [{ text: "📧 Написать Email", url: "mailto:vadimchumaev@mail.ru" }],
        [{ text: "🌐 Открыть сайт", url: "https://vadim-psiholog.ru" }],
      ],
    },
  })
}

// Экстренная помощь
function handleEmergency(chatId) {
  const message = `
🆘 *ЭКСТРЕННАЯ ПОМОЩЬ*

⚠️ *Если вам нужна немедленная помощь:*

🚨 *Суицидальные мысли:*
• Телефон доверия: 8-800-2000-122
• Служба экстренной помощи: 112

💊 *Наркологическая помощь:*
• Горячая линия: 8-800-200-0-200

👥 *Психологическая поддержка:*
• Телефон доверия: 8-495-575-87-70
• Круглосуточно и бесплатно

📱 *Мой экстренный контакт:*
+7 (916) 705-91-10
(в критических ситуациях отвечу сразу)

🏥 *При острых состояниях:*
Обратитесь в ближайшую больницу
или вызовите скорую: 103

💡 *Техники самопомощи:*
• Дыхательные упражнения
• Заземление (5-4-3-2-1)
• Холодная вода на лицо
• Связь с близкими

🤝 *Помните:*
Вы не одни. Помощь всегда доступна.
Любой кризис временен.

❤️ *Я готов помочь вам справиться*
  `

  bot.sendMessage(chatId, message, {
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "📞 Экстренный звонок мне", url: "tel:+79167059110" }],
        [{ text: "🆘 Телефон доверия", url: "tel:88002000122" }],
        [{ text: "🚨 Вызвать скорую", url: "tel:103" }],
      ],
    },
  })
}

// FAQ
function handleFAQ(chatId) {
  const message = `
❓ *ЧАСТЫЕ ВОПРОСЫ*

*Q: Как проходит первая консультация?*
A: Знакомство, выяснение запроса, план работы. Длится 50 минут.

*Q: Сколько нужно сессий?*
A: Индивидуально. От 3-5 для конкретной проблемы до 10-20 для глубокой работы.

*Q: Можно ли онлайн?*
A: Да! Онлайн-терапия так же эффективна, как очная.

*Q: Гарантируете ли конфиденциальность?*
A: Абсолютно. Это основа психологической этики.

*Q: Что если не подойдет ваш подход?*
A: Порекомендую коллегу с подходящей специализацией.

*Q: Работаете с детьми?*
A: С подростками от 14 лет. Детей младше - через родителей.

*Q: Можно отменить/перенести сессию?*
A: Да, за 24 часа без штрафа.

*Q: Какие методы используете?*
A: КПТ, гештальт-терапия, системная терапия.

*Q: Выдаете справки?*
A: Нет, я психолог, не врач. Справки выдают психиатры.

*Q: Стоимость может измениться?*
A: Цены фиксированы на весь курс терапии.
  `

  bot.sendMessage(chatId, message, {
    parse_mode: "Markdown",
    ...mainMenu,
  })
}

// Отзывы
function handleReview(chatId) {
  bot.sendMessage(
    chatId,
    `
📝 *ОСТАВИТЬ ОТЗЫВ*

Ваше мнение очень важно для меня!

Напишите отзыв о нашей работе:
• Что понравилось?
• Что помогло больше всего?
• Что можно улучшить?

Отзыв можно оставить:
🔸 Анонимно (просто напишите здесь)
🔸 С именем (для публикации на сайте)

Также буду благодарен за:
⭐ Оценку в Google
⭐ Отзыв на Яндекс.Картах
⭐ Рекомендацию друзьям

*Напишите ваш отзыв следующим сообщением* ⬇️
  `,
    { parse_mode: "Markdown" },
  )

  // Устанавливаем состояние ожидания отзыва
  users.set(chatId, { ...users.get(chatId), waitingForReview: true })
}

// Конфиденциальность
function handlePrivacy(chatId) {
  const message = `
🔒 *КОНФИДЕНЦИАЛЬНОСТЬ*

*Ваша приватность - мой приоритет*

🛡️ *Что я гарантирую:*
• Полная конфиденциальность всех сессий
• Никто не узнает о факте обращения
• Содержание бесед остается между нами
• Записи сессий не ведутся

📋 *Исключения (по закону):*
• Угроза жизни вам или другим
• Жестокое обращение с детьми
• Судебное предписание

💾 *Хранение данных:*
• Контакты: в защищенной базе
• История сессий: в зашифрованном виде
• Удаление по запросу в любой момент

🔐 *Технические меры:*
• Шифрование переписки
• Защищенные каналы связи
• Регулярное удаление логов

📜 *Этический кодекс:*
Следую международным стандартам психологической этики

❌ *Никогда не разглашаю:*
• Личные данные клиентов
• Содержание сессий
• Факт обращения за помощью

✅ *Ваше право:*
• Знать какие данные храню
• Требовать их удаления
• Контролировать использование

*Доверие - основа нашей работы* ❤️
  `

  bot.sendMessage(chatId, message, {
    parse_mode: "Markdown",
    ...mainMenu,
  })
}

// Обработка callback кнопок
bot.on("callback_query", (callbackQuery) => {
  const message = callbackQuery.message
  const data = callbackQuery.data
  const chatId = message.chat.id

  switch (data) {
    case "service_individual":
      bookService(chatId, "Индивидуальная терапия", 1500)
      break
    case "service_family":
      bookService(chatId, "Семейная терапия", 2500)
      break
    case "service_online":
      bookService(chatId, "Онлайн консультация", 1500)
      break
    case "service_diagnosis":
      bookService(chatId, "Диагностика расстройств", 2000)
      break
    case "main_menu":
      bot.sendMessage(chatId, "Главное меню:", mainMenu)
      break
  }

  // Убираем "часики" с кнопки
  bot.answerCallbackQuery(callbackQuery.id)
})

// Функция бронирования услуги
function bookService(chatId, serviceName, price) {
  const message = `
✅ *Выбрана услуга:* ${serviceName}
💰 *Стоимость:* ${price}₽

📅 *Выберите удобное время:*

🗓️ *Доступные дни:*
Понедельник - Пятница

⏰ *Время сеансов:*
Выберите подходящий слот ⬇️
  `

  bot.sendMessage(chatId, message, {
    parse_mode: "Markdown",
    ...timeMenu,
  })

  // Сохраняем выбранную услугу
  appointments.set(chatId, {
    service: serviceName,
    price: price,
    step: "time_selection",
  })
}

// Обработка выбора времени
bot.on("callback_query", (callbackQuery) => {
  const data = callbackQuery.data
  const chatId = callbackQuery.message.chat.id

  if (data.startsWith("time_")) {
    const time = data.replace("time_", "") + ":00"
    const appointment = appointments.get(chatId)

    if (appointment) {
      appointment.time = time
      appointments.set(chatId, appointment)

      requestContactInfo(chatId, appointment)
    }
  }

  bot.answerCallbackQuery(callbackQuery.id)
})

// Запрос контактной информации
function requestContactInfo(chatId, appointment) {
  const message = `
📋 *ОФОРМЛЕНИЕ ЗАПИСИ*

✅ *Услуга:* ${appointment.service}
💰 *Стоимость:* ${appointment.price}₽  
⏰ *Время:* ${appointment.time}

Для завершения записи укажите:

*Напишите ваше имя:*
  `

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" })

  // Устанавливаем состояние ожидания имени
  appointment.step = "waiting_name"
  appointments.set(chatId, appointment)
}

// Обработка ввода данных для записи
bot.on("message", (msg) => {
  const chatId = msg.chat.id
  const text = msg.text
  const user = users.get(chatId)
  const appointment = appointments.get(chatId)

  // Обработка отзыва
  if (user && user.waitingForReview) {
    bot.sendMessage(
      chatId,
      `
🙏 *Спасибо за отзыв!*

"${text}"

Ваше мнение поможет мне стать лучше и поможет другим людям принять решение об обращении за помощью.

❤️ *Благодарю за доверие!*
    `,
      { parse_mode: "Markdown", ...mainMenu },
    )

    // Убираем флаг ожидания отзыва
    user.waitingForReview = false
    users.set(chatId, user)
    return
  }

  // Обработка записи на прием
  if (appointment && appointment.step === "waiting_name") {
    appointment.clientName = text
    appointment.step = "waiting_phone"
    appointments.set(chatId, appointment)

    bot.sendMessage(
      chatId,
      `
✅ *Имя:* ${text}

*Теперь укажите ваш телефон:*
(например: +7 916 705 91 10)
    `,
      { parse_mode: "Markdown" },
    )
    return
  }

  if (appointment && appointment.step === "waiting_phone") {
    appointment.clientPhone = text
    appointment.step = "completed"
    appointments.set(chatId, appointment)

    confirmAppointment(chatId, appointment)
    return
  }
})

// Подтверждение записи
function confirmAppointment(chatId, appointment) {
  const appointmentId = Date.now().toString().slice(-6)

  const message = `
🎉 *ЗАПИСЬ ПОДТВЕРЖДЕНА!*

📋 *Детали записи:*
🆔 *Номер:* #${appointmentId}
👤 *Имя:* ${appointment.clientName}
📱 *Телефон:* ${appointment.clientPhone}
🎯 *Услуга:* ${appointment.service}
💰 *Стоимость:* ${appointment.price}₽
⏰ *Время:* ${appointment.time}

📞 *Что дальше:*
1. Я свяжусь с вами в течение 2-3 часов
2. Подтвердим точную дату и время
3. Пришлю адрес встречи (для очных сессий)
4. Отвечу на все вопросы

💳 *Оплата:*
Наличными или картой на сессии
(онлайн - предоплата)

📝 *Подготовка к сессии:*
• Подумайте о том, что хотите обсудить
• Приходите за 5 минут до времени
• Возьмите воду

⚠️ *Отмена/перенос:*
Сообщите за 24 часа - без штрафа

❤️ *Жду встречи с вами!*
Вместе мы найдем решение ваших вопросов.

*Хорошего дня!* 🌟
  `

  bot.sendMessage(chatId, message, {
    parse_mode: "Markdown",
    ...mainMenu,
  })

  // Отправляем уведомление психологу (в реальности - на email или в админ-чат)
  console.log(`Новая запись: ${JSON.stringify(appointment)}`)

  // Очищаем данные записи
  appointments.delete(chatId)
}

// Обработка ошибок
bot.on("polling_error", (error) => {
  console.log("Polling error:", error)
})

console.log("🤖 Бот психолога запущен!")
