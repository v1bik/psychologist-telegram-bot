// app/api/telegram/route.js
import TelegramBot from "node-telegram-bot-api"

const token = process.env.BOT_TOKEN
if (!token) {
  throw new Error("BOT_TOKEN env variable is missing")
}

// create the bot once – polling disabled (we’ll use webhooks)
const bot = new TelegramBot(token, { polling: false })

// Optionally reuse across hot-reloads in dev
globalThis._telegramBot ??= bot

export async function POST(req) {
  try {
    const update = await req.json()
    await globalThis._telegramBot.processUpdate(update)
    return new Response(JSON.stringify({ ok: true }))
  } catch (err) {
    console.error("Telegram webhook error:", err)
    return new Response(JSON.stringify({ ok: false }), { status: 500 })
  }
}

export function GET() {
  return new Response("Method Not Allowed", { status: 405 })
}
