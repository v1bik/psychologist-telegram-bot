import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  const bookingData = await request.json()

  // Отправка на вашу почту
  const emailData = {
    to: "vadimchumaev@mail.ru",
    subject: `Новая запись: ${bookingData.service}`,
    html: `
      <h2>Новая заявка на запись</h2>
      <p><strong>Имя:</strong> ${bookingData.name}</p>
      <p><strong>Телефон:</strong> ${bookingData.phone}</p>
      <p><strong>Email:</strong> ${bookingData.email}</p>
      <p><strong>Услуга:</strong> ${bookingData.service}</p>
      <p><strong>Дата:</strong> ${bookingData.date}</p>
      <p><strong>Время:</strong> ${bookingData.time}</p>
      <p><strong>Сообщение:</strong> ${bookingData.message}</p>
    `,
  }

  // Здесь код отправки email

  return NextResponse.json({ success: true })
}
