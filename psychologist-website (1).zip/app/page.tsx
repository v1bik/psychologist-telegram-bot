"use client"

import type React from "react"

import { useState } from "react"
import { Calendar, Clock, Heart, Mail, MapPin, Phone, Star, User, CreditCard } from "lucide-react"
import Image from "next/image"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import PaymentForm from "@/components/payment-form"
import { usePhotoStorage } from "@/hooks/use-photo-storage"
import BookingModal from "@/components/booking-modal"

export default function PsychologistWebsite() {
  const { photo: psychologistPhoto } = usePhotoStorage()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  })

  const [paymentModal, setPaymentModal] = useState({ isOpen: false, service: "", price: 0 })
  const [bookingModal, setBookingModal] = useState({ isOpen: false, serviceType: "" })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Здесь будет логика отправки формы
    console.log("Form submitted:", formData)
    alert("Спасибо за обращение! Я свяжусь с вами в ближайшее время.")
    setFormData({ name: "", email: "", phone: "", message: "" })
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handlePayment = (service: string, price: number) => {
    setPaymentModal({ isOpen: true, service, price })
  }

  const processPayment = (paymentData: any) => {
    // Здесь будет интеграция с платежной системой
    console.log("Processing payment:", paymentData)
    alert(
      `Оплата ${paymentModal.price}₽ за ${paymentModal.service} прошла успешно! Вы получите подтверждение на email.`,
    )
    setPaymentModal({ isOpen: false, service: "", price: 0 })
  }

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  const handleBooking = (serviceType = "") => {
    setBookingModal({ isOpen: true, serviceType })
  }

  const handleContact = () => {
    scrollToSection("contact")
  }

  const handleCall = () => {
    window.open("tel:+79167059110", "_self")
  }

  const handleEmail = () => {
    window.open("mailto:vadimchumaev@mail.ru", "_self")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900"> </span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#about" className="text-gray-700 hover:text-blue-600 transition-colors">
                О себе
              </a>
              <a href="#services" className="text-gray-700 hover:text-blue-600 transition-colors">
                Услуги
              </a>
              <a href="#prices" className="text-gray-700 hover:text-blue-600 transition-colors">
                Цены
              </a>
              <a href="#contact" className="text-gray-700 hover:text-blue-600 transition-colors">
                Контакты
              </a>
            </nav>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => handleBooking()}>
              <Phone className="h-4 w-4 mr-2" />
              Записаться
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-200">Психолог-консультант</Badge>
              <h1 className="text-5xl font-bold text-gray-900 mb-6">Чумаев Вадим Дмитриевич</h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Помогаю людям найти внутреннюю гармонию, преодолеть трудности и построить здоровые отношения.
                Индивидуальная и семейная психотерапия с профессиональным подходом.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700" onClick={() => handleBooking()}>
                  <Calendar className="h-5 w-5 mr-2" />
                  Записаться на консультацию
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-blue-600 text-blue-600 hover:bg-blue-50"
                  onClick={handleContact}
                >
                  <Phone className="h-5 w-5 mr-2" />
                  Связаться со мной
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="relative z-10">
                <Image
                  src={psychologistPhoto || "/placeholder.svg"}
                  alt="Вадим Чумаев - Психолог"
                  width={500}
                  height={600}
                  className="rounded-2xl shadow-2xl object-cover"
                />
              </div>
              <div className="absolute -top-4 -right-4 w-72 h-72 bg-blue-200 rounded-full opacity-20"></div>
              <div className="absolute -bottom-4 -left-4 w-48 h-48 bg-indigo-200 rounded-full opacity-20"></div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">О себе</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Профессиональный психолог с современным подходом к решению личных и семейных проблем
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Card className="p-8 shadow-lg border-0 bg-gradient-to-br from-blue-50 to-indigo-50">
                <CardContent className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <div className="bg-blue-600 p-3 rounded-full">
                      <User className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">Образование</h3>
                      <p className="text-gray-600">Московская международная аккадемия</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="bg-blue-600 p-3 rounded-full">
                      <Clock className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">Опыт работы</h3>
                      <p className="text-gray-600">2 года практической деятельности</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="bg-blue-600 p-3 rounded-full">
                      <Star className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">Специализация</h3>
                      <p className="text-gray-600">Индивидуальная и семейная терапия</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-gray-900">Мой подход к работе</h3>
              <p className="text-gray-600 leading-relaxed">
                Я верю, что каждый человек обладает внутренними ресурсами для преодоления трудностей. Моя задача —
                помочь вам их обнаружить и эффективно использовать.
              </p>
              <p className="text-gray-600 leading-relaxed">
                В работе использую современные методы психотерапии, адаптированные под индивидуальные потребности
                каждого клиента. Создаю безопасное пространство для открытого диалога и личностного роста.
              </p>
              <div className="grid grid-cols-2 gap-4 pt-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">50+</div>
                  <div className="text-sm text-gray-600">Довольных клиентов</div>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">50+</div>
                  <div className="text-sm text-gray-600">Проведенных сессий</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Услуги</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Профессиональная психологическая помощь для решения различных жизненных ситуаций
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                <div className="bg-blue-100 p-3 rounded-full w-fit mb-4">
                  <User className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>Индивидуальная терапия</CardTitle>
                <CardDescription>Работа с личными проблемами, тревожностью, депрессией, самооценкой</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Преодоление тревожности и страхов</li>
                  <li>• Работа с депрессивными состояниями</li>
                  <li>• Повышение самооценки</li>
                  <li>• Решение внутренних конфликтов</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                <div className="bg-green-100 p-3 rounded-full w-fit mb-4">
                  <Heart className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle>Семейная терапия</CardTitle>
                <CardDescription>Восстановление отношений, решение семейных конфликтов</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Улучшение коммуникации в паре</li>
                  <li>• Решение семейных конфликтов</li>
                  <li>• Работа с детско-родительскими отношениями</li>
                  <li>• Подготовка к разводу</li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                <div className="bg-purple-100 p-3 rounded-full w-fit mb-4">
                  <Calendar className="h-6 w-6 text-purple-600" />
                </div>
                <CardTitle>Онлайн консультации</CardTitle>
                <CardDescription>Удобный формат работы из любой точки мира</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Видеосвязь через Zoom/Telegram</li>
                  <li>• Гибкое расписание</li>
                  <li>• Конфиденциальность</li>
                  <li>• Экономия времени на дорогу</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Prices Section */}
      <section id="prices" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Стоимость услуг</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">Прозрачные цены без скрытых платежей</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="relative overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <div className="absolute top-0 right-0 bg-blue-600 text-white px-4 py-1 text-sm">Популярно</div>
              <CardHeader className="text-center pb-8">
                <CardTitle className="text-2xl">Индивидуальная консультация</CardTitle>
                <div className="text-4xl font-bold text-blue-600 mt-4">1500 ₽</div>
                <CardDescription className="text-lg">за сеанс 50 минут</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 p-1 rounded-full">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  </div>
                  <span> Встреча онлайн</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 p-1 rounded-full">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  </div>
                  <span>Полная конфиденциальность</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 p-1 rounded-full">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  </div>
                  <span>Индивидуальный подход</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 p-1 rounded-full">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  </div>
                  <span>Домашние задания</span>
                </div>
                <div className="flex flex-col gap-2">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700" onClick={() => handleBooking("individual")}>
                    Записаться на сеанс
                  </Button>
                  <Button
                    onClick={() => handlePayment("Индивидуальная консультация", 1500)}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    <CreditCard className="h-4 w-4 mr-2" />
                    Оплатить сейчас - 1500 ₽
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-shadow duration-300">
              <CardHeader className="text-center pb-8">
                <CardTitle className="text-2xl">Семейная терапия</CardTitle>
                <div className="text-4xl font-bold text-green-600 mt-4">2500 ₽</div>
                <CardDescription className="text-lg">за сеанс 60 минут</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 p-1 rounded-full">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  </div>
                  <span>Работа с парой или семьей</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 p-1 rounded-full">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  </div>
                  <span>Увеличенная продолжительность</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 p-1 rounded-full">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  </div>
                  <span>Техники семейной терапии</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 p-1 rounded-full">
                    <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                  </div>
                  <span>Рекомендации для всей семьи</span>
                </div>
                <div className="flex flex-col gap-2">
                  <Button className="w-full bg-green-600 hover:bg-green-700" onClick={() => handleBooking("family")}>
                    Записаться на терапию
                  </Button>
                  <Button
                    onClick={() => handlePayment("Семейная терапия", 2500)}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    <CreditCard className="h-4 w-4 mr-2" />
                    Оплатить сейчас - 2500 ₽
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">Первая консультация со скидкой 20% для новых клиентов</p>
            <Badge className="bg-orange-100 text-orange-800 text-lg px-4 py-2">Акция: первый сеанс всего 1200 ₽</Badge>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Связаться со мной</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Готов ответить на ваши вопросы и записать на консультацию
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <Card className="p-8 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl mb-6">Отправить сообщение</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <Label htmlFor="name">Имя *</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        className="mt-1"
                        placeholder="Ваше имя"
                      />
                    </div>

                    <div>
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="mt-1"
                        placeholder="your@email.com"
                      />
                    </div>

                    <div>
                      <Label htmlFor="phone">Телефон</Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="mt-1"
                        placeholder="+7 (999) 123-45-67"
                      />
                    </div>

                    <div>
                      <Label htmlFor="message">Сообщение *</Label>
                      <Textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        required
                        className="mt-1 min-h-[120px]"
                        placeholder="Расскажите о вашей ситуации или задайте вопрос..."
                      />
                    </div>

                    <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                      <Mail className="h-4 w-4 mr-2" />
                      Отправить сообщение
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-8">
              <Card className="p-6 cursor-pointer hover:shadow-md transition-shadow" onClick={handleCall}>
                <div className="flex items-center space-x-4">
                  <div className="bg-blue-100 p-3 rounded-full">
                    <Phone className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Телефон</h3>
                    <p className="text-gray-600">+7 (916) 705-91-10</p>
                  </div>
                </div>
              </Card>

              <Card className="p-6 cursor-pointer hover:shadow-md transition-shadow" onClick={handleEmail}>
                <div className="flex items-center space-x-4">
                  <div className="bg-green-100 p-3 rounded-full">
                    <Mail className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Email</h3>
                    <p className="text-gray-600">vadimchumaev@mail.ru</p>
                  </div>
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="bg-purple-100 p-3 rounded-full">
                    <MapPin className="h-6 w-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Адрес</h3>
                    <p className="text-gray-600">Москва</p>
                  </div>
                </div>
              </Card>

              <Card className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="bg-orange-100 p-3 rounded-full">
                    <Clock className="h-6 w-6 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Часы работы</h3>
                    <p className="text-gray-600">Пн-Пт: 10:00-20:00</p>
                    <p className="text-gray-600">Сб-Вс: Выходной</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Heart className="h-6 w-6 text-blue-400" />
                <span className="text-xl font-bold"> </span>
              </div>
              <p className="text-gray-400 leading-relaxed">
                Профессиональная психологическая помощь для обретения внутренней гармонии и решения жизненных
                трудностей.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Услуги</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Индивидуальная терапия</li>
                <li>Семейная терапия</li>
                <li>Онлайн консультации</li>
                <li>Диагностика психических расстройств</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Контакты</h3>
              <div className="space-y-2 text-gray-400">
                <p>+7 (916) 705-91-10</p>
                <p>vadimchumaev@mail.ru</p>
                <p>Москва</p>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024-2025 Все права защищены.</p>
          </div>
        </div>
      </footer>
      {/* Payment Modal */}
      <Dialog open={paymentModal.isOpen} onOpenChange={(open) => setPaymentModal({ ...paymentModal, isOpen: open })}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Оплата услуги</DialogTitle>
            <DialogDescription>
              {paymentModal.service} - {paymentModal.price} ₽
            </DialogDescription>
          </DialogHeader>
          <PaymentForm
            service={paymentModal.service}
            price={paymentModal.price}
            onPayment={processPayment}
            onCancel={() => setPaymentModal({ isOpen: false, service: "", price: 0 })}
          />
        </DialogContent>
      </Dialog>
      {/* Booking Modal */}
      <BookingModal
        isOpen={bookingModal.isOpen}
        onClose={() => setBookingModal({ isOpen: false, serviceType: "" })}
        serviceType={bookingModal.serviceType}
      />
    </div>
  )
}
