"use client"

import { useState, useEffect } from "react"

export function usePhotoStorage() {
  const [photo, setPhoto] = useState<string>("/images/vadim-photo.jpg")

  // Загрузка фото из localStorage при инициализации
  useEffect(() => {
    const savedPhoto = localStorage.getItem("psychologist-photo")
    if (savedPhoto) {
      setPhoto(savedPhoto)
    }
  }, [])

  // Сохранение фото в localStorage при изменении
  const updatePhoto = (newPhoto: string) => {
    setPhoto(newPhoto)
    localStorage.setItem("psychologist-photo", newPhoto)
  }

  return { photo, updatePhoto }
}
